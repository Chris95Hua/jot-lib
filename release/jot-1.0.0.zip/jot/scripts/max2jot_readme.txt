
3D STUDIO MAX TO JOT SCRIPT - README
Salman Butt, 2003
CS Department, Princeton University
May 28, 2003

Version 0.8
----------------------------------------------

1 DESCRIPTION

This script converts a 3D Studio Max scene into a Jot scene. This scene can then be annotated and rendered in Jot to achieve a variety of artistic effects.

2 INSTRUCTIONS

Jot does not have a system to handle bones, spacewarps, and many of the advanced features of Max. Thus if you know that you will ultimately use Jot for the final rendering process, take care during the modelling and animation phase of your project. For ideal results, your geometry should be able to readily be converted to editable meshes in Max. Your animation techniques should also affect vertex positions directly, since Jot understands animation as the motion of vertex positions. This also implies that there is no notion of camera animation in Jot, so any camera motion in Max will be useless in Jot. Instead, the location of the camera in the first frame exported will be used as the fixed camera location in Jot.

The current implementation of this script does not process through all modifiers to determine final vertex positions, thus animation effects (such as the Bomb object) do not work in Jot. Bones are also currently unsupported. Both of these issues could surely be implemented, but time did not allow for it.

STEP 1:
Once you have a scene that is ready for Jot, ensure that there are no lights and your first camera (Camera01) is set to the position you want to render. Go to the Render Scene dialog box and enter the desired width and height of your render window under the Output Size section.

STEP 2:
Fix your animation range (start and end time) by right-clicking any of the animation buttons on the bottom right of the Max window (e.g. on the Key Mode toggle button - the key button). This will set the frames to be exported to Jot.

STEP 2:
Run the max2jot script by going to MAXScript>Run Script on the Max menubar. Find where you have saved the max2jot script, select it and hit Open.

STEP 3:
Name and save your jot scene. Note that the script will automatically put a .jot extension on your filename, so you only need to give the filename prefix. That is, enter 'scene' instead of 'scene.jot'.

Max will now step through all the frames in your animation range and export each to Jot files. Once all the frames are done, you will get a message box letting you know the process is completed. You should now have all the necessary Jot files in the folder to which you saved the scene. Happy Jotting!

3 KNOWN ISSUES

The max2jot script works with mesh geometry, patches, closed splines (after they have been converted to meshes) and closed NURBS curves (after they have been converted to NURBS surfaces or to meshes). NURBS surfaces also work, though animating their vertices causes problems. The spring object also works, though if it is linked to two objects, its position is altered in the Jot file. Standard transformations (rotations, translations and scales) work perfectly, as do free form and parametric modifiers.

Particle systems, spacewarps and complicated animation (such as bones systems) are not yet implemented. Using them will cause a variety of errors currently. Thus they should be avoided.

4 CONTACT
Questions can be directed to Salman Butt (sbutt@alumni.princeton.edu) or Adam Finkelstein (af@cs.princeton.edu).