Lightwave to Jot Converstion Plug-In

*** Documentation to come... For now, see Tutorial #4 in manual for directions. ***