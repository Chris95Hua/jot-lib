Quick Start
-=-=-=-=-=-

Setup:
======

(1) UnZip jot.zip to some root directory, DEST.

(2) Edit DEST\jot\batch\jot-config.bat to reflect correct JOT_ROOT.
    (i.e. JOT_ROOT <--- DEST\jot)

(3) Right-click 'jot-cmd' shortcut in Explorer and adjust path for
    jot-config.bat to reflect your JOT_ROOT directory
    (i.e. full path is JOT_ROOT\batch\jot-config.bat)


Fire it up:
==========

(1) Double click 'jot-cmd' shortcut to launch command line.
    (Should open to JOT_ROOT directory and jot welcome prompt...)

(2) Type 'chdir manual\tutorials\tutorial-1\' 

(3) Type 'jotq cactus-1.jot'

(4) Follow the tutorial in the manual...

Versions:
=========

jotd - Debug version (debug symbols, assertions, not optimized)    
jotq - Optimized version (debug symbols, assertions, optimized) SAFEST BET!
jotr - Release (no debug symbols, no assertions, optimized)

Manual:
=======

JOT_ROOT/manual - In both .html and .pdf formats.


