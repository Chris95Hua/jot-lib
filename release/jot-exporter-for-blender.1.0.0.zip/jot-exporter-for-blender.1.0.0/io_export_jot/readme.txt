See http://ragnarb.com/toolbox/jot-exporter-for-blender/ for documentation.
